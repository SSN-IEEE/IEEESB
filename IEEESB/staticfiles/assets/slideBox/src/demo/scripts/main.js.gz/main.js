var gaProperty = 'UA-258870-1';
	
// @codekit-prepend 'includes/codeformatting.js'
// @codekit-prepend 'includes/smoothscroll.js'

// @codekit-append 'ga-tracking.js'

// jshint ignore:start

var debug = false,
	mobile = false,
	imgDirDefault = 'assets/images/';

$(function () {

	initSlides();
	
});